3200 - Distributed Systems - Assignment 1

Enrico Tedeschi, ete011
Mike Murphy, mmu019

/doc
	in this folder latex files and the final report are stored.
	
/src
	the code is located here
	
to run the code:
	--if you want to get a list of random nodes--
	sh list_random_hosts.sh #num_hosts
	
	sh startup.sh <host-list>
	python storage_frontend.py --runtests <node>
